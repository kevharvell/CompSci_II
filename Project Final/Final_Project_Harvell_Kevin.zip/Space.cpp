/*****************************************************************************
 * Program name: Space
 * Author: Kevin Harvell
 * Date: 6/8/2018
 * Description: Space is an abstract base class representing room spaces in a
 * haunted house.
*****************************************************************************/

#include "Space.hpp"


Space::~Space() {

}
